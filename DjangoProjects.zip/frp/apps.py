from django.apps import AppConfig


class FrpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'frp'
